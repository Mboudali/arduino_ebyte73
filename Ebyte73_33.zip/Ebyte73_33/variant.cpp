/*
Pin assignment - Ebyte 73 nRF52833 - arduino

Author: M. Boudali
Date created: 11/07/2023
Last edited: 11/07/2023
*/

#include "variant.h"

const uint32_t g_ADigitalPinMap[] = {
  // 0 - 7 > analog inputs
  2,  // A0, p0.02		0
  3,  // A1, p0.03		1
  4,  // A2, p0.04		2
  5,  // A3, p0.05		3
  28, // A4, p0.28		4
  29, // A5, p0.29		5
  30, // A6, p0.30		6
  31, // A7, p0.31		7

  // 8 - 11 > low frequency I/O
  25, // p0.25			8
  36, // p1.04			9
  37, // p1.05			10
  38, // p1.06 			11
  
  // 12 to 23 > GPIO
  6,  // p0.06			12
  7,  // p0.07			13
  8,  // p0.08			14
  12, // p0.12			15
  13, // p0.13			16
  15, // p0.15			17
  17, // p0.17			18
  20, // p0.20			19
  26, // p0.26			20
  32, // p1.00			21
  34, // p1.02			22
  41, // p1.09			23
  
  // 24 to 26 > QSPI
  18, // p0.18 > QSPI/CSN/external reset 	24
  22, // p0.22 > QSPI						25
  24, // p0.24 > QSPI						26
  
  // 27 to 28 > NFC
  9,  // p0.09 > NFC input					27
  10, // p0.10 > NFC input					28

  // 29 to 30 > other
  0,  // p0.00, Connected to crystal 		29
  1,  // p0.01, Connected to crystal		30
  
  // I2C > any pins can be assigned to SDA SCL

};
