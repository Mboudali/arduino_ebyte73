/*
Pin assignment - Ebyte 73 nRF52833 - arduino

Author: M. Boudali
Date created: 11/07/2023
Last edited: 11/07/2023
*/

// API compatibility
#include "variant.h"
