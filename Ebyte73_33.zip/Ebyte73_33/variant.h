/*
Variant - Ebyte 73 nRF52833 - arduino

Author: M. Boudali
Date created: 11/07/2023
Last edited: 11/07/2023
*/
#ifndef _Ebyte73_nRF52833_
#define _Ebyte73_nRF52833_

// Master clock frequency
#define VARIANT_MCK (64000000ul)

#include "WVariant.h"

#ifdef __cplusplus
extern "C"
{
#endif // __cplusplus

// Number of pins defined in PinDescription array

#define PINS_COUNT			(31)
#define NUM_DIGITAL_PINS	(23)
#define NUM_ANALOG_INPUTS	(8)
#define NUM_ANALOG_OUTPUTS	(0)

// Analog pins
#define PIN_A0				(0)
#define PIN_A1				(1)
#define PIN_A2				(2)
#define PIN_A3				(3)
#define PIN_A4				(4)
#define PIN_A5				(5)
#define PIN_A6				(6)
#define PIN_A7				(7)

#define ADC_RESOLUTION 14
static const uint8_t A0 = PIN_A0;
static const uint8_t A1 = PIN_A1;
static const uint8_t A2 = PIN_A2;
static const uint8_t A3 = PIN_A3;
static const uint8_t A4 = PIN_A4;
static const uint8_t A5 = PIN_A5;
static const uint8_t A6 = PIN_A6;
static const uint8_t A7 = PIN_A7;

// LEDs - 13 was chosen to reflect Arduino "standard". 
#define PIN_LED             (13)
//#define LED_BUILTIN         PIN_LED // ebyte73 does not have a built in LED. Uncomment if your PCB has an LED connected to ebyte73 GPIO 13. 

// Low frequency I/O, standard drive
#define PIN_LowF_1			(8)
#define PIN_LowF_2			(9)
#define PIN_LowF_3			(10)
#define PIN_LowF_4			(11)

// GPIO
#define PIN_gpio0			(12)
#define PIN_gpio1			(13)
#define PIN_gpio2			(14)
#define PIN_gpio3			(15)
#define PIN_gpio4			(16)
#define PIN_gpio5			(17)
#define PIN_gpio6			(18)
#define PIN_gpio7			(19)
#define PIN_gpio8			(20)
#define PIN_gpio9			(21)
#define PIN_gpio10			(22)
#define PIN_gpio11			(23)

// QSPI - !!!NOT TESTED!!!
//#define SPI_INTERFACES_COUNT 1
//#define PIN_SPI_MISO		(14)
//#define PIN_SPI_MOSI		(15)
//#define PIN_SPI_SCK		(13)
#define PIN_QSPI_rst		(24)
#define PIN_QSPI_0			(25)
#define PIN_QSPI_1			(26)

// Wire Interfaces (external and internal)
#define WIRE_INTERFACES_COUNT 2
#define PIN_WIRE_SDA		(20)
#define PIN_WIRE_SCL		(21)
#define PIN_WIRE1_SDA       (22)
#define PIN_WIRE1_SCL       (23)
static const uint8_t SDA = PIN_WIRE_SDA;
static const uint8_t SCL = PIN_WIRE_SCL;
static const uint8_t SDA1 = PIN_WIRE1_SDA;
static const uint8_t SCL1 = PIN_WIRE1_SCL;

// NFC
#define PIN_NFC0			(27)
#define PIN_NFC1			(28)

// Crystal
#define PIN_Crystal0 		(29)
#define PIN_Crystal1		(30)

// SPI 
#define SPI_INTERFACES_COUNT 1
#define PIN_SPI_MISO		(25)
#define PIN_SPI_MOSI		(26)
#define PIN_SPI_SCK			(24)

// Serial
#define PIN_SERIAL_RX		(25)
#define PIN_SERIAL_TX		(26)

#ifdef __cplusplus
}
#endif // __cplusplus

#endif
